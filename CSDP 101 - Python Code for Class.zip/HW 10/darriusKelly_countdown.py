"""
File name: darriusKelly_countdown.py
Author: Darrius Kelly
ID: 1340034
Last version date: 11/13/2024
Short description: Countdown from input number to zero.
"""

#Display purpose
print("This program will countdown \
from the number you enter!")
#get input
num = int(input("Enter a starting number for the countdown: "))
#create statement
while(num>0):
    print(num)
    num -= 1
print("Blast off!")


'''
This program will countdown from the number you enter!
Enter a starting number for the countdown: 10
10
9
8
7
6
5
4
3
2
1
Blast off!

'''