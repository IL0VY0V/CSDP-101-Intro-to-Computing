"""
File name: darriusKelly_password.py
Author: Darrius Kelly
ID: 1340034
Last version date: 11/13/2024
Short description: Have user input username and password
"""

#Display purpose
print("This program will as you to enter your\
username and password!")
#get username
username = input("Enter your username: ")
#check for username
while(username != "TestUser01"):
    print("Wrong username! Try again!")
    username = input("Enter your username: ")
#get password
password = input("Enter your password: ")
#check for password
while(password != "Python12345"):
    print("Wrong password! Try again!")
    password = input("Enter your password: ")
#They have logged in!
print("Login Sucessful!")


'''
This program will as you to enter yourusername and password!
Enter your username: Test
Wrong username! Try again!
Enter your username: TestUser01
Enter your password: Python
Wrong password! Try again!
Enter your password: Python12345
Login Sucessful!

'''