"""
File name: darriusKelly_gradeReport.py
Author: Darrius Kelly ケリーダリウス
ID: 1340034
Last version date: 11/05/2024
Short description: This program will determine the user's letter grade based on percentage.
"""
#Display purpose
print("Hello! This program will calcuate your letter grade \
based on the percentage given.")
#Get inputs
student_Name = input("Enter your name: ")
student_ID = int(input("Enter your student ID (XXXXXXX): "))
course_ID = input("Enter your course ID (four letters for class\
subject and three numbers for course level): ")
course_Name = input("Enter the name of your course: ")
semester = input("Enter the semester: ")
#Get input for statement
grade_Numeric = float(input("Enter your grade percentage: "))
#create if-elif statements
if(grade_Numeric <100 >=90):
    letter_Grade = "A"
elif(grade_Numeric < 90>= 80):
    letter_Grade = "B"
elif(grade_Numeric < 80 >= 70):
    letter_Grade = "C"
elif(grade_Numeric < 70 >= 60):
    letter_Grade = "D"
elif(grade_Numeric < 60):
    letter_Grade = "F"
#If grade is invalid, show error message
else:
    letter_Grade = "ERROR! Please restart program!"
    print("ERROR! Please restart program!")
#Print outputs:
print("---------------------------------------")
print("Student Grade Report")
print("---------------------------------------")
print("Student Name: "+ student_Name)
print("Student ID: ",student_ID)
print("Course ID:"+ course_ID)
print("Course Name: "+ course_Name)
print("Semester Term: "+ semester)
print("Final Grade (Numeric):", grade_Numeric,"%")
print("Final Grade (Letter): "+ letter_Grade)
'''
Hello! This program will calcuate your letter grade based on the percentage given.
Enter your name: Darrius Kelly
Enter your student ID (XXXXXXX): 1340034
Enter your course ID (four letters for classsubject and three numbers for course level): CSDP101
Enter the name of your course: Intro to Computer
Enter the semester: Fall 2024
Enter your grade percentage: 92.93
---------------------------------------
Student Grade Report
---------------------------------------
Student Name: Darrius Kelly
Student ID:  1340034
Course ID:CSDP101
Course Name: Intro to Computer
Semester Term: Fall 2024
Final Grade (Numeric): 92.93 %
Final Grade (Letter): A

'''