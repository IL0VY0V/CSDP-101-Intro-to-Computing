"""
darriusKelly_calculator.py
Darrius Kelly
ID: 1340034
Last version date: 11/03/2024
Short description: This program will act as a basic calculator. Listed below is the code, followed by all possible outputs.
"""
#Display purpose (and have some fun with it, too!)
print('Loading "Basic Calculator"...')
print('"Basic Calculator" loaded!')
print("Welcome to the basic calculator! \
This program will allow you do to addition, subtraction, multiplication, \
or division of two numbers!")
#Get the two numbers that will be used for the equation from user.
num1 = float(input("Enter the first number of the equation: "))
num2 = float(input("Enter the second number of the equation: "))
#Get input for operation
selection = int(input("You're operation options are: \n 1: Addition (+) \n 2: Subtraction (-) \
\n 3: Multiplication (*) \n 4: Division (/) \n \
Choose the operation you wish to perform (1-4):"))
#Create if-elif statement
#If selection is 1, perform addition
if(selection == 1):
    addition = num1 + num2
    print('The addition of' ,num1, 'and', num2, 'is', addition)
#If selection is 2, perform subtraction
elif(selection == 2):
    subtraction = num1 - num2
    print('The subtraction of' ,num1, 'and', num2, 'is', subtraction)
#If selection is 3, perform multiplication
elif(selection == 3):
    multiplication = num1 * num2
    print('The multiplication of' ,num1, 'and', num2, 'is', multiplication)
#If selection is 4, perform division
elif(selection == 4):
    division = num1 / num2
    print('The division of' ,num1, 'and', num2, 'is', division)
#If selection is invalid, show error message
else:
    print("ERROR! INVALID SELECTION! PLEASE RESTART THE PROGRAM!")
print("Thank you for using this basic calculator!")

'''
Output For Addition:
Loading "Basic Calculator"...
"Basic Calculator" loaded!
Welcome to the basic calculator! This program will allow you do to addition, subtraction, multiplication, or division of two numbers!
Enter the first number of the equation: 5
Enter the second number of the equation: 5
You're operation options are:
 1: Addition (+)
 2: Subtraction (-)
 3: Multiplication (*)
 4: Division (/)
 Choose the operation you wish to perform (1-4):1
The addition of 5.0 and 5.0 is 10.0
Thank you for using this basic calculator!

Output for Subtraction:
Loading "Basic Calculator"...
"Basic Calculator" loaded!
Welcome to the basic calculator! This program will allow you do to addition, subtraction, multiplication, or division of two numbers!
Enter the first number of the equation: 5
Enter the second number of the equation: 5
You're operation options are:
 1: Addition (+)
 2: Subtraction (-)
 3: Multiplication (*)
 4: Division (/)
 Choose the operation you wish to perform (1-4):2
The subtraction of 5.0 and 5.0 is 0.0
Thank you for using this basic calculator!

Output for Multiplication:
Loading "Basic Calculator"...
"Basic Calculator" loaded!
Welcome to the basic calculator! This program will allow you do to addition, subtraction, multiplication, or division of two numbers!
Enter the first number of the equation: 5
Enter the second number of the equation: 5
You're operation options are:
 1: Addition (+)
 2: Subtraction (-)
 3: Multiplication (*)
 4: Division (/)
 Choose the operation you wish to perform (1-4):3
The multiplication of 5.0 and 5.0 is 25.0
Thank you for using this basic calculator!

Output for Division:
Loading "Basic Calculator"...
"Basic Calculator" loaded!
Welcome to the basic calculator! This program will allow you do to addition, subtraction, multiplication, or division of two numbers!
Enter the first number of the equation: 5
Enter the second number of the equation: 5
You're operation options are:
 1: Addition (+)
 2: Subtraction (-)
 3: Multiplication (*)
 4: Division (/)
 Choose the operation you wish to perform (1-4):4
The division of 5.0 and 5.0 is 1.0
Thank you for using this basic calculator!

Output for Else:
Loading "Basic Calculator"...
"Basic Calculator" loaded!
Welcome to the basic calculator! This program will allow you do to addition, subtraction, multiplication, or division of two numbers!
Enter the first number of the equation: 5
Enter the second number of the equation: 5
You're operation options are:
 1: Addition (+)
 2: Subtraction (-)
 3: Multiplication (*)
 4: Division (/)
 Choose the operation you wish to perform (1-4):5
ERROR! INVALID SELECTION! PLEASE RESTART THE PROGRAM!
Thank you for using this basic calculator!
'''