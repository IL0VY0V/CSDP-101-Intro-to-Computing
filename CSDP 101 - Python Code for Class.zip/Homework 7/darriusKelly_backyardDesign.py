'''
Darrius Kelly
darriusKelly_backyardDesign.py
1340034
10/23/24
This program will determine if a circular or sqaure backyard design is more cost effective.
'''
#Display the purpose
print("This program will ask you to input the longest length of your backyard\
and tell you if a cicular design or square design is more cost effective.")
#Get input for length in feet and ask what design they want.
length = float(input("Enter the longest length of your backyard in feet: "))
choice = input("Choose your design. (Circular or sqaure): ")
#Do calculations for circular
#The diameter is the length. Setting the length as the diameter first makes the code easier to understand.
diameter = length
#Now we find the radius by dividing the diameter by 2
radius = diameter/2
#Now we find the area
area = 3.14*(radius**2)
#Now we find the cost
totalCir = area*170
#Do calculations for sqaure design
#We should reassign the length as the width to make the calculations more understandable.
width = length
#Now we find the area
area2 = width**2
#Now we find the cost
totalSq = area2*170
#Fancy prints
print("----------------------------------------")
print("Circular Backyard:")
print("Diameter:", diameter, "Feet.")
print("Radius:", radius, 'Feet.')
print("Area:", area, "sqaure feet.")
print("Total cost: $",totalCir)
print("----------------------------------------")
print("Sqaure Backyard:")
print("Width:", width, "Feet.")
print("Area:", area2,"sqaure feet.")
print("Total cost: $",totalSq)
#If statement
if(totalCir < totalSq):
    print("It is more cost effective to do the circular design.")
else:
    print("It is more cost effective to do the square design.")
'''
Output:
This program will ask you to input the longest length of your backyardand tell you if a cicular design or square design is more cost effective.
Enter the longest length of your backyard in feet: 30
Choose your design. (Circular or sqaure): Sqaure
----------------------------------------
Circular Backyard:
Diameter: 30.0 Feet.
Radius: 15.0 Feet.
Area: 706.5 sqaure feet.
Total cost: $ 120105.0
----------------------------------------
Sqaure Backyard:
Width: 30.0 Feet.
Area: 900.0 sqaure feet.
Total cost: $ 153000.0
It is more cost effective to do the circular design.
'''