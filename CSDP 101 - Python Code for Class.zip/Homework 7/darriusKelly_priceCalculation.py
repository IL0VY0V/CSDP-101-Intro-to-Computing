'''
Darrius Kelly
darriusKelly_priceCalculation.py
1340034
10/23/24
This program will determine the final cost of each two products/items and total cost combined based on what percentage discount is applied to the products.
'''
#Display the purpose
#Disclaimer, item 1 is the first product and item 2 is the second product. It is used interchangeably in the program and represents the same thing. It is easier to write item1.
print('This program will ask you to provide two products and their cost. \
With that, we will determine the final price of each product seperately depending on \
cost of each product and the discount applied. Then, we will comine the final prices for a total price.')
#Let us get the inputs for product names and product prices
#Item_1_Name is the name of the item, while item1 is the price of the item.
item_1_Name = input("Enter the name of the first product: ")
item1 = float(input("Enter the price of the first product: "))
print("   ")
item_2_Name = input("Enter the name of the second product: ")
item2 = float(input("Enter the price of the second product: "))
#Now it is time for the if statements of item 1
if(item1 >= 50):
    #If item 1 is greater than or equal to 50, apply 15% discount
    discountper = 0.15
    discount = item1*discountper
    #Since the final price has a 15% discount, we will signify that it is the final price of item 1 with a 15% discount.
    finalPrice = item1-discount
else:
    #If item 1 is less than 50, apply 5% discount
    discountper = 0.05
    discount = item1*discountper
    #Since the final price has a 5% discount, we will signify that it is the final price of item 1 with a 5% discount.
    finalPrice = item1-discount
if(item2 >= 50):
    #If item 2 is greater than or equal to 50, apply 15% discount
    discountper2 = 0.15
    discount2 = item2*discountper2
    #Since the final price has a 15% discount, we will signify that it is the final price of item 2 with a 15% discount.
    finalPrice2 = item2-discount2
else:
    #If item 2 is less than 50, apply 5% discount
    discountper2 = 0.05
    discount2 = item2*discountper2
    #Since the finl price has a 5% discount, we will signify that it is the final price of item 2 with a 5% discount.
    finalPrice2 = item2-discount2
#Now we add the total
total = finalPrice + finalPrice2
#Let us display our findings of product 1
print(' ')
print('----------------------------------------')
print('Product:' , item_1_Name)
print("Original price: $",item1)
print("Discount: $",discount , "%",discountper)
print("Final price: $",finalPrice)
#Let us display our findings of product 2
print('----------------------------------------')
print('Product:' , item_2_Name)
print("Original price: $",item2)
print("Discount: $",discount2 , "%",discountper2)
print("Final price: $",finalPrice2)
#Let us print our total cost
print('----------------------------------------')
print("total price for both products: $",total)
'''
Output: 
This program will ask you to provide two products and their cost. With that, we will determine the final price of each product seperately depending on cost of each product and the discount applied. Then, we will comine the final prices for a total price.
Enter the name of the first product: Shoes
Enter the price of the first product: 60

Enter the name of the second product: Books
Enter the price of the second product: 10

----------------------------------------
Product: Shoes
Original price: $ 60.0
Discount: $ 9.0 % 0.15
Final price: $ 51.0
----------------------------------------
Product: Books
Original price: $ 10.0
Discount: $ 0.5 % 0.05
Final price: $ 9.5
----------------------------------------
total price for both products: $ 60.5
'''