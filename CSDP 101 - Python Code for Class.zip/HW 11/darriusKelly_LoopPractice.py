"""
File name: darriusKelly_LoopPractice.py
Author: Darrius Kelly
ID: 1340034
Last version date: 11/19/2024
Short description: This program will count down from positive integer to 1, count up from negative integer to -1, or display 0
"""

# display purpose
print('This program will count down from positive integer to 1, \
count up from negative integer to -1, or display 0.')
# get integer
integer = int(input("Enter your integer of \
choice: "))
#create if-elif state to determine what for loop to execute.
if(integer > 0):
    #if integer is positive, count down
     for num in range (integer, 0, -1):
         #print num
         print(num)
elif(integer < 0):
    #if integer is negative, count up
     for num in range (integer, 0, 1):
         #print num
         print(num)
else:
    #if integer is zero, print 0
    print("0")
print("End")
'''
This program will count down from positive integer to 1, count up from negative integer to -1, or display 0.
Enter your integer of choice: 8
8
7
6
5
4
3
2
1
End

This program will count down from positive integer to 1, count up from negative integer to -1, or display 0.
Enter your integer of choice: -6
-6
-5
-4
-3
-2
-1
End

This program will count down from positive integer to 1, count up from negative integer to -1, or display 0.
Enter your integer of choice: 0
0
End
'''
