"""
File name: darriusKelly_guessNum.py
Author: Darrius Kelly
ID: 1340034
Last version date: 11/19/2024
Short description: The user will have to guess the target number 27.
"""

# display purpose
print("This program will ask you to \
guess the winning number!")
# get input
guess = int(input("Input your guess (1~100): "))
#create statement
while(guess!=27):
    print("Incorrect!")
    #if incorrect, create if statement to see if it was high or low
    if(guess>27):
        #the guess was too high
        print("Number is too high!")
        guess = int(input("Input your new guess (1~100): "))
    else:
        #the guess was too low
        print("Number is too low!")
        guess = int(input("Input your new guess (1~100): "))
# they got the guess correct! Print winning value
print("Correct! The winning value was 27!")
print("End.")


'''
This program will ask you to guess the winning number!
Input your guess (1~100): 10
Incorrect!
Number is too low!
Input your new guess (1~100): 50
Incorrect!
Number is too high!
Input your new guess (1~100): 27
Correct! The winning value was 27!
End.

'''
