"""
darriusKelly_bounsCalculate.py
Darrius Kelly
ID: 1340034
Last version date: 10/29/2024
Short description: This program will determine the percentage of bonus an employee will receive.
"""
#Display purpose
print('This program will determine your bonus based on \
years of service and salary!')
#Get input for years of service. This is a float because the amount of years worked is not always a 1:1 ratio. Some workers may have worked for 18 months, or 1.5 years.
years = float(input("Enter the amount of years \
you've worked: "))
#Created if statement on if they have worked longer than five years
if(years>5):
    #get second input for salary
    salary = float(input("Please input your yearly salary (without commas): "))
    #Created nested if statement if salary is over $50,000
    if(salary>50000):
        #They get a 10% bonus
        print("You get a 10'%' bonus!")
    #If they do not make a 50,000 salary, they get a 5% bonus
    else:
        print("You get a 5'%' bonus!")
#If they have not worked for 5 years, they will get a 2% bonus
else:
    print("You get a 2'%' bonus!")
"""
Oytput 1:
This program will determine your bonus based on years of service and salary!
Enter the amount of years you've worked: 5
You get a 2'%' bonus!

Output 2:
This program will determine your bonus based on years of service and salary!
Enter the amount of years you've worked: 6
Please input your yearly salary (without commas): 60000
You get a 10'%' bonus!

Output 3:
This program will determine your bonus based on years of service and salary!
Enter the amount of years you've worked: 6
Please input your yearly salary (without commas): 20000
You get a 5'%' bonus!

"""
