"""
File name: darriusKelly_gradeEvaluate.py
Author: Darrius Kelly
ID: 1340034
Last version date: 11/06/2024
Short description: This program will determine if a student has passed their class.
"""

#Display purpose
print("This program will determine if you have \
passed your class based on grade, attendence, and behavior.")
#input grade
grade = float(input("Enter your grade for the class\
(0-100): "))
#create nested if statement
if(grade >= 70):
    #Get attendence
    attendence = float(input("Enter your attendence percentage (0-100): "))
    #create another if statement for attendence
    if(attendence >= 80):
        #get behavior score
        behavior = float(input("Enter your behavior (scored from 0-10): "))
        #Create final if statement
        if(behavior >= 7):
            #If all statements are true, they passed
            print("You passed~!")
        #The behavior was under 7
        else:
            print("Bad students don't pass! You failed due to low behavior!")
    #The attendence failed to meet the required minimum percentage
    else:
        print("Only students who show up pass the class!\
        Raise your attendence and go to class more! Failed.")
#The grade was too low and was under 70
else:
    print("How can you expect to pass a class with a low grade? You failed.")
print("Have a good day!")

'''
This program will determine if you have passed your class based on grade, attendence, and behavior.
Enter your grade for the class(0-100): 9
How can you expect to pass a class with a low grade? You failed.
Have a good day!

This program will determine if you have passed your class based on grade, attendence, and behavior.
Enter your grade for the class(0-100): 90
Enter your attendence percentage (0-100): 60
Only students who show up pass the class! Raise your attendence and go to class more! Failed.
Have a good day!

This program will determine if you have passed your class based on grade, attendence, and behavior.
Enter your grade for the class(0-100): 90
Enter your attendence percentage (0-100): 80
Enter your behavior (scored from 0-10): 5
Bad students don't pass! You failed due to low behavior!
Have a good day!

This program will determine if you have passed your class based on grade, attendence, and behavior.
Enter your grade for the class(0-100): 80
Enter your attendence percentage (0-100): 90
Enter your behavior (scored from 0-10): 9
You passed~!
Have a good day!

'''
