"""
File name: darriusKelly_commissionRate.py
Author: Darrius Kelly
ID: 1340034
Last version date: 11/06/2024
Short description: Determine the commission rate from sales amount
"""

# display purpose
print("The program will determine the commission rate\
based on the sales amount (in dollars)")
#display table
print("-------------------------------------------")
print("Sales                  Commission Rate")
print("-------------------------------------------")
print("Up to $10,000                  10%")
print("$10,000 to $15,000             15%")
print("Over $15,000                   20%")
print("-------------------------------------------")
#Get input for sales amount
sales_Amount = float(input("Enter the sales amount (numeric): "))
#create if-elif statement
if(sales_Amount < 10000):
    commission_Rate = "10%"
elif(sales_Amount <=15000>=10000):
    commission_Rate = "15%"
else:
    commission_Rate = "20%"
print("The commission rate for $",sales_Amount ,"is "+ commission_Rate)

'''
The program will determine the commission ratebased on the sales amount (in dollars)
-------------------------------------------
Sales                  Commission Rate
-------------------------------------------
Up to $10,000                  10%
$10,000 to $15,000             15%
Over $15,000                   20%
-------------------------------------------
Enter the sales amount (numeric): 9000
The commission rate for $ 9000.0 is 10%

The program will determine the commission ratebased on the sales amount (in dollars)
-------------------------------------------
Sales                  Commission Rate
-------------------------------------------
Up to $10,000                  10%
$10,000 to $15,000             15%
Over $15,000                   20%
-------------------------------------------
Enter the sales amount (numeric): 10000
The commission rate for $ 10000.0 is 15%

The program will determine the commission ratebased on the sales amount (in dollars)
-------------------------------------------
Sales                  Commission Rate
-------------------------------------------
Up to $10,000                  10%
$10,000 to $15,000             15%
Over $15,000                   20%
-------------------------------------------
Enter the sales amount (numeric): 20000
The commission rate for $ 20000.0 is 20%

'''