'''
Title: darriusKelly_spending.py
Author: Darrius Kelly
Date: 10/8/24
Purpose: Track the user's spending over five days by collecting the amount spent on each day.
'''
#Display purpose
print("This program will help you track your\
money spending over a five day period.")
#Input for the money spent each day
day1 = float(input("How much did you spend on the first day?: "))
day2 = float(input("How much did you spend on the second day?: "))
day3 = float(input("How much did you spend on the third day?: "))
day4 = float(input("How much did you spend on the fourth day?: "))
day5 = float(input("How much did you spend on the fifth day?: "))
#Calculate the total spend in total
totalSpent = day1+day2+day3+day4+day5
#Next, we need to calculate the average
Avg = totalSpent//5
#Display total spent and average
print('The total amount spent over the five days is $', totalSpent)
print('The average money spent is $', Avg)
'''
Output
This program will help you track yourmoney spending over a five day period.
How much did you spend on the first day?: 5.75
How much did you spend on the second day?: 2.2
How much did you spend on the third day?: 50
How much did you spend on the fourth day?: 28
How much did you spend on the fifth day?: 10.3
The total amount spent over the five days is $ 96.25
The average money spent is $ 19.0
'''