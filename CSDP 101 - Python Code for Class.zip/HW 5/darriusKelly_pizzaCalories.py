'''
Name: darriusKelly_pizzaCalories.py
Author: Darrius Kelly
Date: 10/8/24
Purpose: This program will find total calories consumed by user based on amount of pizza eaten.
'''
# Display the purpose
print("This code will determine the amount of calories you \
consumed based off how many slices of pizza you ate.")
# We must ask for the amount of slices consumed.
consumedSlices = int(input('Input the amount of slices you have consumed: '))
# Assign variables and calculate total consumed calories based off variables
fullPizzaCalories = 2400
oneSliceCalories = fullPizzaCalories/8
totalConsumedCalories = oneSliceCalories*consumedSlices
# The next few lines are to check for possible logic errors
# Print the amount of calories per 8 slices
print('You consumed', consumedSlices, "slices of pizza.")
print("A full 8 slices of pizza has", fullPizzaCalories , "calories.")
# Print amount for one slice
print('The amount of calories for one slice of pizza is', oneSliceCalories, "calories.")
# Print total consumed calories
print('The amount of calories you consumed is', totalConsumedCalories, "calories.")
# Thank the user for using the program
print("Thank you! Always remember to not consume too much calories!")
'''
Output
This code will determine the amount of calories you consumed based off how many slices of pizza you ate.
Input the amount of slices you have consumed: 4
You consumed 4 slices of pizza.
A full 8 slices of pizza has 2400 calories.
The amount of calories for one slice of pizza is 300.0 calories.
The amount of calories you consumed is 1200.0 calories.
Thank you! Always remember to not consume too much calories!
'''