'''
File Name: darriusKelly_ChristmasParty.py
Author: Darrius Kelly
ID: 1340034
Short Description: To determine if user can attend a Christmas party
'''
#display purpose
print("This program will determine if \
you are eligible to attend the 2024 Christmas Party!!!")
#Input user's name
name = input("Please enter your name: ")
#get input for user's age
age = int(input("Please enter your age: "))
#Create nested if statement. if the user is 18, continue to the second statement
if(age >= 18):
    #the user is 18, so now we ask if they have a ticket
    ticket = input("Have you purchased a ticket? (Y/N): ")
    #create nested if statement for ticket
    if(ticket == "Y"):
        #they are allowed to attend
        print("You are allowed to attend! \n See you at the party!")
    #they do not have a ticket or they input an incorrect value
    else:
        #they cannot attend. No ticket
        print("Sorry! You must have a ticket in \
        order to attend the party!")
#they are too young to attend the party
else:
    #they cannot attend the party. Too young
    print("Sorry! You are too young to attend this party!")
#the program has ended
print("Merry Christmas!")

'''
Output:
This program will determine if you are eligible to attend the 2024 Christmas Party!!!
Please enter your name: Darrius
Please enter your age: 17
Sorry! You are too young to attend this party!
Merry Christmas!

This program will determine if you are eligible to attend the 2024 Christmas Party!!!
Please enter your name: Darrius
Please enter your age: 18
Have you purchased a ticket? (Yes/No): No
Sorry! You must have a ticket in order to attend the party!
Merry Christmas!

This program will determine if you are eligible to attend the 2024 Christmas Party!!!
Please enter your name: Darrius
Please enter your age: 19
Have you purchased a ticket? (Y/N): Y
You are allowed to attend!
 See you at the party!
Merry Christmas!
'''