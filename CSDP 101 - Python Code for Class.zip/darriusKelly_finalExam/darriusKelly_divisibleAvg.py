'''
File Name: darriusKelly_divisibleAvg.py
Author: Darrius Kelly
ID: 1340034
Short Description: To determine if user can attend a Christmas party
'''
#display purpose
print("This program will idenitify numbers \
divisible by both 3 and 4 within a range and calculates \
the average.")
print("Please enter the two integers that will define the range. Make sure the numbers \
are not the same.")
#get input for integer one
firstnumber = int(input("Please enter the first number: "))
#get input for integer two
secondnumber = int(input("Please enter the second number: "))
#determine if numbers are the same
while(firstnumber == secondnumber):
    print("The two numbers cannot be the same.")
    #get input for second number again
    secondnumber = int(input("Please enter the second number: "))
#create if statement. if first is bigger than second
if(firstnumber > secondnumber):
    #set start as the second number and end as the first number
    start = secondnumber
    end = firstnumber
#else means second number is bigger
else:
    #reverse
    start = firstnumber
    end = secondnumber
#print the start and end
print("Numbers divisible by 3 and 4 within the range of", start, "to", end)
#set accumulator
divisible = 0
counter = 0
#create for loop
for num in range(start+1, end, 1):
    #determine if number is divisible by 3 and 4
    if(num % 3 == 0):
        if(num % 4 == 0):
            #print the number
            print(num)
            #add the number to the accumulator
            divisible += num
            #add one to the counter
            counter += 1
#divide total by counter
average = divisible/counter
#print the average
print("The average of them is" ,average)
print("End")

'''
This program will idenitify numbers divisible by both 3 and 4 within a range and calculates the average.
Please enter the two integers that will define the range. Make sure the numbers are not the same.
Please enter the first number: 10
Please enter the second number: 50
Numbers divisible by 3 and 4 within the range of 10 to 50
12
24
36
48
The average of them is 30.0
End
'''