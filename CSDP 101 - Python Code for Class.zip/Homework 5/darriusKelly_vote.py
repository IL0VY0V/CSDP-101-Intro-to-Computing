'''
darriusKelly_vote.py
Darrius Kelly
1340034
10/15/24
This program will determine if the user is eligible to vote.
'''
#First we must display the purpose
print("This program will determine if you can vote!")
#Now we need the age of the user
age = int(input("Please input your age: "))
#So if the age is greater than or equal to 18 we print they can vote
if (age >= 18):
    print("You are eligible to vote!")
#If younger, we print that they cannot vote.
else:
    print('You are not eligible to vote!')
'''
Output True:
This program will determine if you can vote!
Please input your age: 18
You are eligible to vote!

Output False:
This program will determine if you can vote!
Please input your age: 12
You are not eligible to vote!
'''