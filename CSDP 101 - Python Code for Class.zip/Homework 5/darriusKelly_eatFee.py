'''
darriusKelly_eatFee.py
Darrius Kelly
1340034
10/15/24
This program will determine the final cost of a meal based on the base price and amount of people dining.
'''
#Display purpose
print('This program will calcuate the final cost of your meal based \
on the base cost, the total amount of people dining, tax, discount, and tip.')
#Get inputs
base = float(input("What was the base price of the meal: $"))
people = int(input("How many people dined with you today: "))
#Determine the if people > 8.
#If so:
if(people > 8):
    #Find tip
    tip = base*.25
    #Find the price before discount
    baseTip = base+tip
    #Find discount
    discount = (baseTip)*.12
    #Apply discount
    total = baseTip-discount
#If people is less than or equal to 8:
if (people <= 8):
    #Find tip
    tip = base*.15
    #Find total without adding discount
    total = (base+tip)
#Both statements will have the following calculations
#Deterime tax
tax = total*0.08
#Determine final cost
final = tax+total
#Display final cost
print("You final price was $", final)
'''
Output A:
This program will calcuate the final cost of your meal based on the base cost, the total amount of people dining, tax, discount, and tip.
What was the base price of the meal: $10
How many people dined with you today: 2
You final price was $ 12.42
Output B:
This program will calcuate the final cost of your meal based on the base cost, the total amount of people dining, tax, discount, and tip.
What was the base price of the meal: $10
How many people dined with you today: 9
You final price was $ 11.88
'''